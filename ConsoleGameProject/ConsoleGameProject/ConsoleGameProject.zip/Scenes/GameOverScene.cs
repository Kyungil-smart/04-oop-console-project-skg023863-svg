﻿

public class GameOverScene : Scene
{
    private MenuList _GameOverMenu;
    public GameOverScene()
    {
        Init();
    }

    public void Init()
    {
        _GameOverMenu = new MenuList();
        _GameOverMenu.Add("다시 시작", PlayAgain);
        _GameOverMenu.Add("타이틀로", GotoTitle);
    }
    public override void Enter()
    {

    }

    public override void Exit()
    {

    }

    public override void Render()
    {
        Console.SetCursorPosition(5, 1);
        Console.WriteLine("Game Over");
    }

    public override void Update()
    {
        if (InputManager.GetKey(ConsoleKey.UpArrow))
        {
            _GameOverMenu.SelectUp();
        }

        if (InputManager.GetKey(ConsoleKey.DownArrow))
        {
            _GameOverMenu.SelectDown();
        }

        if (InputManager.GetKey(ConsoleKey.Enter))
        {
            _GameOverMenu.Select();
        }
    }

    private void GotoTitle()
    {
        SceneManager.Change("Circuit");
    }

    private void PlayAgain()
    {
        SceneManager.Change("Title");
    }
}

