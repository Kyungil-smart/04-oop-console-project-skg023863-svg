﻿public class Obstacle : GameObject
{

}

